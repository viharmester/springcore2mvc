package com.andorid.service.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.andorid.dao.TicketImp;
import com.andorid.service.TicketService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class TicketServiceTest {

    @Autowired
    private TicketService ticketService;

    @Test
    public void testBookingTicket() {

        var ticketImp = ticketService.bookTicket(1, 1, 1, TicketImp.Category.BAR);

        assertNotNull(ticketImp);
        assertEquals(0, ticketImp.getId());
        assertEquals(1, ticketImp.getUserId());
        assertEquals(1, ticketImp.getEventId());
        assertEquals(1, ticketImp.getPlace());
        assertEquals(TicketImp.Category.BAR, ticketImp.getCategory());
    }

}
