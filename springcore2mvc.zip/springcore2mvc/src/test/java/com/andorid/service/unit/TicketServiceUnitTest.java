package com.andorid.service.unit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.andorid.dao.TicketImp;
import com.andorid.repository.TicketRepository;
import com.andorid.service.TicketService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class TicketServiceUnitTest {

    @Mock
    private TicketRepository repository;

    @InjectMocks
    private TicketService service;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testTicketBooking() {
        TicketImp aMockTicket = new TicketImp(0, 1, 1, TicketImp.Category.BAR, 1);
        when(repository.save(any(TicketImp.class))).thenReturn(aMockTicket);

        var ticketImp = service.bookTicket(1, 1, 1, TicketImp.Category.BAR);

        assertNotNull(ticketImp);
        assertEquals(0, ticketImp.getId());
        assertEquals(1, ticketImp.getUserId());
        assertEquals(1, ticketImp.getEventId());
        assertEquals(1, ticketImp.getPlace());
        assertEquals(TicketImp.Category.BAR, ticketImp.getCategory());
    }

}
