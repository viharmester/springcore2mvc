package com.andorid.controller.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import com.andorid.controller.TicketController;
import com.andorid.dao.TicketImp;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ui.ConcurrentModel;
import org.springframework.ui.Model;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TicketControllerTest {

    @Autowired
    public TicketController controller;

    @Test
    public void testTicketListing() {
        Model model = new ConcurrentModel();
        var base = controller.base(model);

        assertEquals(base, "ticketIndex.html");
    }

}
