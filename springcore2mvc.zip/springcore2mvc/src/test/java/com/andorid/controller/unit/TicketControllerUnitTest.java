package com.andorid.controller.unit;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;

import com.andorid.controller.TicketController;
import com.andorid.dao.TicketImp;
import com.andorid.service.BookingService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@WebMvcTest(TicketController.class)
public class TicketControllerUnitTest {
    @Autowired
    private MockMvc mockMvc;

    @Mock
    private BookingService bookingService;

    @InjectMocks
    private TicketController controller;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testBase() throws Exception {
        var allTickets = new ArrayList<TicketImp>();
        allTickets.add(new TicketImp(1, 1, 1, TicketImp.Category.BAR, 1));
        allTickets.add(new TicketImp(2, 2, 2, TicketImp.Category.STANDARD, 2));
        when(bookingService.getAllTickets()).thenReturn(allTickets);

        mockMvc.perform(get("/ticket/"))
            .andExpect(status().isOk())
            .andReturn();
    }

}
