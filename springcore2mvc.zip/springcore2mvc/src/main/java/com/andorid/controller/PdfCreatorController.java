package com.andorid.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PdfCreatorController {

    @GetMapping("/pdf/generate/ticket/{ticketId}")
    public String generatePdfTicket() {

        return "ticket/ticketIndex";
    }

    @GetMapping("/pdf/generate/ticket/{userId}")
    public String generatePdfUser() {

        return "ticket/ticketIndex";
    }
}
