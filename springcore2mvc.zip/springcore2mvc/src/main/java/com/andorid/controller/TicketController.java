package com.andorid.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import com.andorid.dao.TicketImp;
import com.andorid.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

@Controller
public class TicketController {

    @Autowired
    private BookingService bookingService;

    @GetMapping("ticket/")
    public String base(Model model) {
        var allTickets = bookingService.getAllTickets();
        model.addAttribute("tickets", allTickets);
        model.addAttribute("user", "nope");
        return "ticketIndex.html";
    }

    @GetMapping("ticket/ticketIndex")
    public String index(Model model) {
        var allTickets = bookingService.getAllTickets();
        model.addAttribute("tickets", allTickets);
        model.addAttribute("user", "nope");
        return "ticketIndex.html";
    }

    @GetMapping("ticket/ticketIndex/{userId}")
    public String ticketsForUser(Model model, @PathVariable("userId") String userId) {
        var userById = bookingService.getUserById(Long.parseLong(userId));
        var bookedTickets = bookingService.getBookedTickets(userById, 20, 0);
        model.addAttribute("tickets", bookedTickets);
        model.addAttribute("user", userById);
        return "ticketIndex.html";
    }

    @GetMapping("ticket/batch")
    public String batchTickets(Model model) {
        var batchedTickets = readFiles();
        bookingService.saveBatchTickets(batchedTickets);
        var allTickets = bookingService.getAllTickets();
        model.addAttribute("tickets", allTickets);
        model.addAttribute("user", "nope");
        return "ticketIndex.html";
    }

    private List<TicketImp> readFiles() {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        var listOfTickets = new ArrayList<TicketImp>();
        try {

            // optional, but recommended
            // process XML securely, avoid attacks like XML External Entities (XXE)
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new ClassPathResource("tickets.xml").getFile());

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            System.out.println("Root Element :" + doc.getDocumentElement().getNodeName());
            System.out.println("------");

            // get <staff>
            NodeList list = doc.getElementsByTagName("ticket");

            for (int temp = 0; temp < list.getLength(); temp++) {

                Node node = list.item(temp);

                if (node.getNodeType() == Node.ELEMENT_NODE) {

                    Element element = (Element) node;

                    // get staff's attribute
                    String id = element.getAttribute("id");
                    String userId = element.getAttribute("userId");
                    String eventId = element.getAttribute("eventId");
                    String category = element.getAttribute("category");
                    String place = element.getAttribute("place");
                    listOfTickets.add(
                        new TicketImp(
                            Long.parseLong(id),
                            Long.parseLong(userId),
                            Long.parseLong(eventId),
                            TicketImp.Category.valueOf(category),
                            Integer.parseInt(place)
                        ));
                }
            }

        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }

        return listOfTickets;
    }
}
