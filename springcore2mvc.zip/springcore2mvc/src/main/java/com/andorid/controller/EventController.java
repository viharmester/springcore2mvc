package com.andorid.controller;

import com.andorid.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EventController {

    @Autowired
    private BookingService bookingService;

    @GetMapping("event/eventIndex")
    public String base(Model model) {
        throw new IllegalArgumentException("Example error");
    }
}
