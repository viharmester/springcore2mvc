package com.andorid.controller;

import com.andorid.dao.UserImp;
import com.andorid.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    @Autowired
    private BookingService bookingService;

    /**
     * Loads all users from the service and returns it to the view.
     *
     * @param model
     * @return the user list view
     */
    @GetMapping("user/userIndex")
    public String index(Model model) {
        var allUsers = bookingService.getAllUsers();
        model.addAttribute("users", allUsers);
        return "userIndex";
    }

    @GetMapping("user/add")
    public String addUser() {
        return "user-form";
    }

    @PostMapping("/user/add")
    public String addUser(@ModelAttribute("addUser") UserImp user, Model model) {
        bookingService.createUser(user);
        model.addAttribute("users", bookingService.getAllUsers());
        return "userIndex";
    }

    @GetMapping("/user/edit/{id}")
    public String getUserToEdit(Model model, @PathVariable("id") int userId) {

        model.addAttribute("editUser", bookingService.getUserById(userId));

        return "user-edit";
    }

    @PostMapping("/user/edit/{id}")
    public String updateUser(@ModelAttribute("editUser") UserImp user, @PathVariable("id") String userId,
                               Model model) {
        bookingService.updateUser(user);

        model.addAttribute("users", bookingService.getAllUsers());
        return "userIndex";
    }

    @GetMapping("/user/delete/{id}")
    public String deleteUser(Model model, @PathVariable("id") int userId) {
        bookingService.deleteUser(userId);
        model.addAttribute("users", bookingService.getAllUsers());
        return "userIndex";
    }
}
