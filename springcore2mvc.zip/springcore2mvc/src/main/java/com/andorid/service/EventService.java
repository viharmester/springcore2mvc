package com.andorid.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.andorid.aspect.Loggable;
import com.andorid.dao.EventImp;
import com.andorid.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    @Loggable
    public Optional<EventImp> getEventById(long eventId) {
        return eventRepository.findById(eventId);
    }

    @Loggable
    public List<EventImp> getEventsByTitle(String title, int pageSize, int pageNum) {
        var events = eventRepository.findAll().stream()
            .filter(item -> item.getTitle().equals(title))
            .collect(Collectors.toList());

        return events.subList((pageSize - 1) * pageNum, Math.min(events.size(), pageSize));
    }

    @Loggable
    public List<EventImp> getEventsForDay(Date day, int pageSize, int pageNum) {
        var events = eventRepository.findAll().stream()
            .filter(item -> item.getDate().equals(day))
            .collect(Collectors.toList());

        return events.subList((pageSize - 1) * pageNum, Math.min(events.size(), pageSize));
    }

    @Loggable
    public EventImp createEvent(EventImp event) {
        eventRepository.findAll().add(event);
        return event;
    }

    @Loggable
    public EventImp updateEvent(EventImp event) {
        eventRepository.save(event);
        return event;
    }

    @Loggable
    public boolean deleteEvent(long eventId) {
        eventRepository.deleteById(eventId);
        return true;
    }

    public List<EventImp> getAllEvents() {
        return eventRepository.findAll();
    }
}
