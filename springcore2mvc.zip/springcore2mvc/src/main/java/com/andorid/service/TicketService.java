package com.andorid.service;

import java.util.List;
import java.util.stream.Collectors;

import com.andorid.aspect.Loggable;
import com.andorid.dao.EventImp;
import com.andorid.dao.TicketImp;
import com.andorid.dao.UserImp;
import com.andorid.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketService {

    @Autowired
    private TicketRepository repository;

    @Loggable
    public TicketImp bookTicket(long userId, long eventId, int place, TicketImp.Category category) {
        TicketImp ticket = new TicketImp(0, eventId, userId, category, place);
        repository.save(ticket);
        return ticket;
    }

    @Loggable
    public List<TicketImp> getBookedTickets(UserImp user, int pageSize, int pageNum) {
        List<TicketImp> tickets = repository.findAll().stream()
            .filter(item -> item.getUserId() == user.getId())
            .collect(Collectors.toList());

        return tickets.subList((pageSize - 1) * pageNum, Math.min(tickets.size(), pageSize));
    }

    @Loggable
    public List<TicketImp> getBookedTickets(EventImp event, int pageSize, int pageNum) {
        List<TicketImp> tickets = repository.findAll().stream()
            .filter(item -> item.getEventId() == event.getId())
            .collect(Collectors.toList());

        return tickets.subList((pageSize - 1) * pageNum, Math.min(tickets.size(), pageSize));
    }

    @Loggable
    public boolean cancelTicket(long ticketId) {
        repository.deleteById(ticketId);
        return true;
    }

    public List<TicketImp> getAllTickets() {
        return repository.findAll();
    }

    public List<TicketImp> saveBatchTickets(List<TicketImp> newTickets) {
        repository.saveAll(newTickets);
        return repository.findAll();
    }
}
