package com.andorid.service;

import java.util.Date;
import java.util.List;

import com.andorid.aspect.Loggable;
import com.andorid.dao.EventImp;
import com.andorid.dao.TicketImp;
import com.andorid.dao.UserImp;
import com.andorid.facade.BookingFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService implements BookingFacade {

    private final EventService eventService;
    private final TicketService ticketService;
    private final UserService userService;

    @Autowired
    public BookingService(EventService eventService, TicketService ticketService, UserService userService) {
        this.eventService = eventService;
        this.ticketService = ticketService;
        this.userService = userService;
    }

    @Loggable
    @Override
    public EventImp getEventById(long eventId) {
        return eventService.getEventById(eventId).orElse(null);
    }

    @Override
    public List<EventImp> getEventsByTitle(String title, int pageSize, int pageNum) {
        return eventService.getEventsByTitle(title, pageSize, pageNum);
    }

    @Override
    public List<EventImp> getEventsForDay(Date day, int pageSize, int pageNum) {
        return eventService.getEventsForDay(day, pageSize, pageNum);
    }

    @Override
    public EventImp createEvent(EventImp event) {
        return eventService.createEvent(event);
    }

    @Override
    public EventImp updateEvent(EventImp event) {
        return eventService.updateEvent(event);
    }

    @Override
    public boolean deleteEvent(long eventId) {
        return eventService.deleteEvent(eventId);
    }

    @Override
    public UserImp getUserById(long userId) {
        return userService.getUserById(userId).orElse(null);
    }

    @Override
    public UserImp getUserByEmail(String email) {
        return userService.getUserByEmail(email).orElse(null);
    }

    @Override
    public List<UserImp> getUsersByName(String name, int pageSize, int pageNum) {
        return userService.getUsersByName(name, pageSize, pageNum);
    }

    @Override
    public UserImp createUser(UserImp user) {
        return userService.createUser(user);
    }

    @Override
    public UserImp updateUser(UserImp user) {
        return userService.updateUser(user);
    }

    @Override
    public boolean deleteUser(long userId) {
        return userService.deleteUser(userId);
    }

    @Override
    public TicketImp bookTicket(long userId, long eventId, int place, TicketImp.Category category) {
        return ticketService.bookTicket(userId, eventId, place, category);
    }

    @Override
    public List<TicketImp> getBookedTickets(UserImp user, int pageSize, int pageNum) {
        return ticketService.getBookedTickets(user, pageSize, pageNum);
    }

    @Override
    public List<TicketImp> getBookedTickets(EventImp event, int pageSize, int pageNum) {
        return ticketService.getBookedTickets(event, pageSize, pageNum);
    }

    @Override
    public boolean cancelTicket(long ticketId) {
        return ticketService.cancelTicket(ticketId);
    }

    public List<UserImp> getAllUsers() {
        return userService.getAllUsers();
    }

    public List<EventImp> getAllEvents() {
        return eventService.getAllEvents();
    }

    public List<TicketImp> getAllTickets() {
        return ticketService.getAllTickets();
    }

    public List<TicketImp> saveBatchTickets(List<TicketImp> newTickets) {
        return ticketService.saveBatchTickets(newTickets);
    }
}
