package com.andorid.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.andorid.aspect.Loggable;
import com.andorid.dao.UserImp;
import com.andorid.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository repository;

    @Loggable
    public Optional<UserImp> getUserById(long userId) {
        return repository.findAll().stream()
            .filter(item -> item.getId() == userId)
            .findFirst();
    }

    @Loggable
    public Optional<UserImp> getUserByEmail(String email) {
        return repository.findAll().stream()
            .filter(item -> item.getEmail().equals(email))
            .findFirst();
    }

    @Loggable
    public List<UserImp> getUsersByName(String name, int pageSize, int pageNum) {
        List<UserImp> users = repository.findAll().stream()
            .filter(item -> item.getName().equals(name))
            .collect(Collectors.toList());

        return users.subList((pageSize - 1) * pageNum, Math.min(users.size(), pageSize));
    }

    @Loggable
    public UserImp createUser(UserImp user) {
        repository.save(user);
        return user;
    }

    @Loggable
    public UserImp updateUser(UserImp user) {
        repository.save(user);
        return user;
    }

    @Loggable
    public boolean deleteUser(long userId) {
        repository.deleteById(userId);
        return true;
    }

    public List<UserImp> getAllUsers() {
        return repository.findAll();
    }
}
