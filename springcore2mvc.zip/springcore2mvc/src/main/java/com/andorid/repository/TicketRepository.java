package com.andorid.repository;

import com.andorid.dao.TicketImp;
import com.andorid.dao.UserImp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketRepository extends JpaRepository<TicketImp, Long> {
}
