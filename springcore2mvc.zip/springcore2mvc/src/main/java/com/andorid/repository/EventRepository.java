package com.andorid.repository;

import com.andorid.dao.EventImp;
import com.andorid.dao.UserImp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventRepository extends JpaRepository<EventImp, Long> {
}
