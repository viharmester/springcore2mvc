package com.andorid.repository;

import com.andorid.dao.UserImp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserImp, Long> {
}
