package com.andorid.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TICKET")
public class TicketImp {
    @Id
    @Column(name = "ID")
    private long id;
    @Column(name = "EVENTID")
    private long eventId;
    @Column(name = "USERID")
    private long userId;
    @Column(name = "CATEGORY")
    private Category category;
    @Column(name = "PLACE")
    private int place;

    public enum Category {
        STANDARD,
        PREMIUM,
        BAR
    }
}
